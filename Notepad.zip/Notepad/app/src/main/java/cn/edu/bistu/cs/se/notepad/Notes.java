package cn.edu.bistu.cs.se.notepad;

import android.provider.BaseColumns;

public class Notes {
    public Notes() { }
    public static abstract class Note implements BaseColumns {
        public static final String TABLE_NAME="Words";
        public static final String COLUMN_NAME_NOTE="word";
        public static final String COLUMN_NAME_TIME="meaning";
    }

}
