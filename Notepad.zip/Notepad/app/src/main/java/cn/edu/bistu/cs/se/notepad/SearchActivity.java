package cn.edu.bistu.cs.se.notepad;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import java.util.ArrayList;
import java.util.Map;

public class SearchActivity extends AppCompatActivity {
    Button back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        Intent intent=getIntent();
        ArrayList<Map<String, String>> items=(ArrayList<Map<String, String>>)intent.getSerializableExtra("result");
        setNotesListView(items);
    }
    private void setNotesListView(ArrayList<Map<String, String>> items){
        SimpleAdapter adapter = new SimpleAdapter(this, items, R.layout.item,new String[]{Notes.Note._ID,Notes.Note.COLUMN_NAME_NOTE, Notes.Note.COLUMN_NAME_TIME},new int[]{R.id.textId,R.id.textViewNote, R.id.textViewTime});
        ListView list = (ListView) findViewById(R.id.SearchListsNotes);
        list.setAdapter(adapter);
    }
}
