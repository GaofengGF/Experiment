package cn.edu.bistu.cs.se.notepad;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.ContextMenu;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    static NotesDBHelper mDbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });


        //为ListView注册上下文菜单
        ListView list = (ListView) findViewById(R.id.listsNotes);
        registerForContextMenu(list);
        //创建SQLiteOpenHelper对象，注意第一次运行时，此时数据库并没有被创建
        mDbHelper = new NotesDBHelper(this);
        //在列表显示全部单词
        ArrayList<Map<String, String>> items=getAll();
        setNotesListView(items);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mDbHelper.close();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        switch (id) {
            case R.id.action_Search:
                //查找
                SearchDialog();
                return true;
            case R.id.action_Insert:
                //新增单词
                InsertDialog();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        getMenuInflater().inflate(R.menu.contextmenu_noteslistview, menu);
    }


    public boolean onContextItemSelected(MenuItem item) {
        TextView textId=null;
        TextView textNote=null;
        TextView textTime=null;
        AdapterView.AdapterContextMenuInfo info=null;
        View itemView=null;
        switch (item.getItemId()){
            case R.id.action_delete:
                //删除
                info=(AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
                itemView=info.targetView;
                textId =(TextView)itemView.findViewById(R.id.textId);
                if(textId!=null){
                    String strId=textId.getText().toString();
                    DeleteDialog(strId);
                }
                break;
            case R.id.action_update:
                //修改
                info=(AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
                itemView=info.targetView;
                textId =(TextView)itemView.findViewById(R.id.textId);
                textNote =(TextView) itemView.findViewById(R.id.textViewNote);
                textTime =(TextView) itemView.findViewById(R.id.textViewTime);
                if(textId!=null && textNote!=null && textTime!=null){
                    String strId=textId.getText().toString();
                    String strNote=textNote.getText().toString();
                    String strTime=textTime.getText().toString();
                    UpdateDialog(strId, strNote, strTime);
                }
                break;
        }
        return true;
    }


    private void setNotesListView(ArrayList<Map<String, String>> items){
        SimpleAdapter adapter = new SimpleAdapter(this, items, R.layout.item,new String[]{Notes.Note._ID,Notes.Note.COLUMN_NAME_NOTE, Notes.Note.COLUMN_NAME_TIME},new int[]{R.id.textId,R.id.textViewNote, R.id.textViewTime});
        ListView list = (ListView) findViewById(R.id.listsNotes);
        list.setAdapter(adapter);
    }

    private void Insert(String strNote,String strTime){
        SQLiteDatabase db = mDbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Notes.Note.COLUMN_NAME_NOTE, strNote);
        values.put(Notes.Note.COLUMN_NAME_TIME, strTime);
        long newRowId;
        newRowId = db.insert(Notes.Note.TABLE_NAME,null,values);
    }


    //新增对话框
    private void InsertDialog() {
        final TableLayout tableLayout = (TableLayout) getLayoutInflater().inflate(R.layout.insert, null);
        Date date = new Date();
        SimpleDateFormat time = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        String dateString = time.format(date);
        ((EditText)tableLayout.findViewById(R.id.txtTime)).setText(dateString);
        new AlertDialog.Builder(this)
                .setTitle("新增事件")//标题
                .setView(tableLayout)//设置视图
                    // 确定按钮及其动作
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String strNote=((EditText)tableLayout.findViewById(R.id.txtNote)).getText().toString();
                        String strTime=((EditText)tableLayout.findViewById(R.id.txtTime)).getText().toString();
                        //既可以使用Sql语句插入，也可以使用使用insert方法插入
                        // InsertUserSql(strWord, strMeaning, strSample);
                        Insert(strNote, strTime);
                        ArrayList<Map<String, String>> items=getAll();
                        setNotesListView(items);
                    }
                })
                //取消按钮及其动作
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {}
                })
                .create()//创建对话框
                .show();//显示对话框
    }


    //删除单词
    private void Delete(String strId) {
        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        // 定义where子句
        String selection = Notes.Note._ID + " = ?";
        // 指定占位符对应的实际参数
        String[] selectionArgs = {strId};
        // Issue SQL statement.
        db.delete(Notes.Note.TABLE_NAME, selection, selectionArgs);
    }


    private void DeleteDialog(final String strId){
        new AlertDialog.Builder(this).setTitle("删除事件").setMessage("是否真的删除事件?").setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                //既可以使用Sql语句删除，也可以使用使用delete方法删除
                //DeleteUseSql(strId);
                Delete(strId);
                setNotesListView(getAll());
            }
        }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {}
        }).create().show();
    }




    //使用方法更新
    private void Update(String strId,String strNote, String strTime) {
        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        // New value for one column
        ContentValues values = new ContentValues();
        values.put(Notes.Note.COLUMN_NAME_NOTE, strNote);
        values.put(Notes.Note.COLUMN_NAME_TIME, strTime);
        String selection =Notes.Note._ID + " = ?";
        String[] selectionArgs = {strId};
        int count = db.update(Notes.Note.TABLE_NAME,values,selection,selectionArgs);
    }


    //修改对话框
    private void UpdateDialog(final String strId, final String strNote, final String strTime) {
        final TableLayout tableLayout = (TableLayout) getLayoutInflater().inflate(R.layout.insert, null);
        ((EditText)tableLayout.findViewById(R.id.txtNote)).setText(strNote);
        ((EditText)tableLayout.findViewById(R.id.txtTime)).setText(strTime);
        new AlertDialog.Builder(this)
                .setTitle("修改事件")//标题
                .setView(tableLayout)//设置视图
                    // 确定按钮及其动作
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //String strId = ((TextView) tableLayout.findViewById(R.id.textId)).getText().toString();
                        String strNewNote = ((EditText) tableLayout.findViewById(R.id.txtNote)).getText().toString();
                        String strNewTime = ((EditText) tableLayout.findViewById(R.id.txtTime)).getText().toString();
                        //既可以使用Sql语句更新，也可以使用使用update方法更新
                        //UpdateUseSql(strId, strNewNote, strNewTime);
                        Update(strId, strNewNote, strNewTime);
                        setNotesListView(getAll());
                    }
                })
                //取消按钮及其动作
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {}
                })
                .create()//创建对话框
                .show();//显示对话框
        }





    //使用query方法查找
    private ArrayList<Map<String, String>> Search(String strNoteSearch) {
        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        String[] projection = {Notes.Note._ID,Notes.Note.COLUMN_NAME_NOTE,Notes.Note.COLUMN_NAME_TIME};
        String sortOrder = Notes.Note.COLUMN_NAME_NOTE + " DESC";
        String selection = Notes.Note.COLUMN_NAME_NOTE + " LIKE ?";
        String[] selectionArgs = {"%"+strNoteSearch+"%"};
        Cursor c = db.query(Notes.Note.TABLE_NAME,// The table to query
                projection,// The columns to return
                selection,// The columns for the WHERE clause
                selectionArgs,// The values for the WHERE clause
                null,// don't group the rows
                null,// don't filter by row groups
                sortOrder// The sort order
        );
        return ConvertCursor2List(c);
    }


    //查询对话框
    private void SearchDialog() {
        final TableLayout tableLayout = (TableLayout) getLayoutInflater().inflate(R.layout.searchterm, null);
        new AlertDialog.Builder(this)
                .setTitle("查询事件")//标题
                .setView(tableLayout)//设置视图
                    // 确定按钮及其动作
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String txtSearchNote=((EditText)tableLayout.findViewById(R.id.txtSearchNote)).getText().toString();
                        ArrayList<Map<String, String>> items=null;
                        //既可以使用Sql语句查询，也可以使用方法查询
                        //items=SearchUseSql(txtSearchNote);
                        items=Search(txtSearchNote);
                        if(items.size()>0) {
                            Bundle bundle=new Bundle();
                            bundle.putSerializable("result",items);
                            Intent intent=new Intent(MainActivity.this,SearchActivity.class);
                            intent.putExtras(bundle);
                            startActivity(intent);
                        }
                        else
                            Toast.makeText(MainActivity.this,"没有找到",Toast.LENGTH_LONG).show();
                    }
                })
                //取消按钮及其动作
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {}
                })
                .create()//创建对话框
                .show();//显示对话框
        }



    public static ArrayList<Map<String, String>> ConvertCursor2List(Cursor cursor) {
        ArrayList<Map<String, String>> result = new ArrayList<>();
        while (cursor.moveToNext()) {
            Map<String, String> map = new HashMap<>();
            map.put(Notes.Note._ID, String.valueOf(cursor.getInt(0)));
            map.put(Notes.Note.COLUMN_NAME_NOTE, cursor.getString(1));
            map.put(Notes.Note.COLUMN_NAME_TIME, cursor.getString(2));
            result.add(map);
        }
        return result;
    }



    public static ArrayList<Map<String, String>> getAll() {
        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        String[] projection = {
                Notes.Note._ID,
                Notes.Note.COLUMN_NAME_NOTE,
                Notes.Note.COLUMN_NAME_TIME
        };
        //排序
        String sortOrder = Notes.Note.COLUMN_NAME_NOTE + " DESC";
        Cursor c = db.query(
                Notes.Note.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                sortOrder
        );
        return ConvertCursor2List(c);
    }
}