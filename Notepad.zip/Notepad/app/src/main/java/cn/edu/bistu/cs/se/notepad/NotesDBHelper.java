package cn.edu.bistu.cs.se.notepad;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class NotesDBHelper extends SQLiteOpenHelper {
    private final static String DATABASE_NAME = "notesDB";//数据库名字
    private final static int DATABASE_VERSION = 1;//数据库版本
    // 建表SQL
    private final static String SQL_CREATE_DATABASE = "CREATE TABLE "
            + Notes.Note.TABLE_NAME + "(" +
            Notes.Note._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            Notes.Note.COLUMN_NAME_NOTE + " TEXT" + "," +
            Notes.Note.COLUMN_NAME_TIME + " TEXT"+")";
            //删表SQL
    private final static String SQL_DELETE_DATABASE = "DROP TABLE IF EXISTS " + Notes.Note.TABLE_NAME;

    public NotesDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //创建数据库
        sqLiteDatabase.execSQL(SQL_CREATE_DATABASE);
    }
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        //当数据库升级时被调用，首先删除旧表，然后调用OnCreate()创建新表
        sqLiteDatabase.execSQL(SQL_DELETE_DATABASE);
        onCreate(sqLiteDatabase);
    }

}
