package cn.edu.bistu.cs.se.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.Stack;

public class MainActivity extends AppCompatActivity {
    EditText show;
    Button bt1;
    Button bt2;
    Button bt3;
    Button bt4;
    Button bt5;
    Button bt6;
    Button bt7;
    Button bt8;
    Button bt9;
    Button bt0;
    Button btPoint;
    Button btAC;
    Button btDivide;
    Button btMultiply;
    Button btSub;
    Button btAdd;
    Button btBackspace;
    Button btEqual;
    Button btLeft;
    Button btRight;
    Button btPercent;
    Button btSin;
    Button btCos;
    Button btTan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        show = (EditText) findViewById(R.id.show);
        bt1 = (Button) findViewById(R.id.buttonOne);
        bt2 = (Button) findViewById(R.id.buttonTwo);
        bt3 = (Button) findViewById(R.id.buttonThree);
        bt4 = (Button) findViewById(R.id.buttonFour);
        bt5 = (Button) findViewById(R.id.buttonFive);
        bt6 = (Button) findViewById(R.id.buttonSix);
        bt7 = (Button) findViewById(R.id.buttonSeven);
        bt8 = (Button) findViewById(R.id.buttonEight);
        bt9 = (Button) findViewById(R.id.buttonNine);
        bt0 = (Button) findViewById(R.id.buttonZero);
        btPoint = (Button) findViewById(R.id.buttonPoint);
        btAC = (Button) findViewById(R.id.buttonClear);
        btDivide = (Button) findViewById(R.id.buttonDivide);
        btMultiply = (Button) findViewById(R.id.buttonMultiply);
        btSub = (Button) findViewById(R.id.buttonSub);
        btAdd = (Button) findViewById(R.id.buttonAdd);
        btBackspace = (Button) findViewById(R.id.buttonBackspace);
        btEqual = (Button) findViewById(R.id.buttonEqual);
        btLeft = (Button) findViewById(R.id.buttonLeft);
        btRight = (Button) findViewById(R.id.buttonRight);
        btPercent = (Button) findViewById(R.id.buttonPercent);
        btSin = (Button) findViewById(R.id.buttonSin);
        btCos = (Button) findViewById(R.id.buttonCos);
        btTan = (Button) findViewById(R.id.buttonTan);

        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show.setText(show.getText()+bt1.getText().toString());
            }
        });

        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show.setText(show.getText()+bt2.getText().toString());
            }
        });

        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show.setText(show.getText()+bt3.getText().toString());
            }
        });

        bt4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show.setText(show.getText()+bt4.getText().toString());
            }
        });

        bt5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show.setText(show.getText()+bt5.getText().toString());
            }
        });

        bt6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show.setText(show.getText()+bt6.getText().toString());
            }
        });

        bt7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show.setText(show.getText()+bt7.getText().toString());
            }
        });

        bt8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show.setText(show.getText()+bt8.getText().toString());
            }
        });

        bt9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show.setText(show.getText()+bt9.getText().toString());
            }
        });

        bt0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show.setText(show.getText()+bt0.getText().toString());
            }
        });

        btPoint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show.setText(show.getText()+btPoint.getText().toString());
            }
        });

        btAC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show.setText(null);
            }
        });

        btDivide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show.setText(show.getText()+btDivide.getText().toString());
            }
        });

        btMultiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show.setText(show.getText()+btMultiply.getText().toString());
            }
        });

        btSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show.setText(show.getText()+btSub.getText().toString());
            }
        });

        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show.setText(show.getText()+btAdd.getText().toString());
            }
        });

        btPercent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s=show.getEditableText().toString();
                float per=Operation.toValue(Operation.toPostfix(s))/100;
                show.setText(show.getText()+"%="+per);
            }
        });

        btEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s=show.getEditableText().toString();
                show.setText(show.getText()+"="+Operation.toValue(Operation.toPostfix(s)));
            }
        });

        btLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show.setText(show.getText()+btLeft.getText().toString());
            }
        });

        btRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show.setText(show.getText()+btRight.getText().toString());
            }
        });

        btBackspace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(show.getText().length()>0){
                    if(show.getText().length()==1){
                        show.setText(null);
                    }
                    else{
                        show.setText(show.getText().toString().subSequence(0,show.getText().length()-1));
                    }
                }
            }
        });

        btSin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s=show.getEditableText().toString();
                DecimalFormat df = new DecimalFormat( "0.00000");
                double value=Math.toRadians(Operation.toValue(Operation.toPostfix(s)));
                double sin=Math.sin((double)value);
                show.setText("sin"+show.getText()+"°="+df.format(sin));
            }
        });

        btCos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s=show.getEditableText().toString();
                DecimalFormat df = new DecimalFormat( "0.00000");
                double value=Math.toRadians(Operation.toValue(Operation.toPostfix(s)));
                double cos=Math.cos((double)value);
                show.setText("cos"+show.getText()+"°="+df.format(cos));
            }
        });

        btTan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s=show.getEditableText().toString();
                DecimalFormat df = new DecimalFormat( "0.00000");
                double value=Math.toRadians(Operation.toValue(Operation.toPostfix(s)));
                double tan=Math.tan((double)value);
                show.setText("tan"+show.getText()+"°="+df.format(tan));
            }
        });
    }

    public static class Operation {
        public static StringBuffer toPostfix(String infix) {
            Stack<String> stack=new Stack<String>();
            StringBuffer postfix=new StringBuffer(infix.length()*2);
            int i=0;
            while(i<infix.length()){
                char ch=infix.charAt(i);
                switch(ch){
                    case '+': case '-':
                        while(!stack.isEmpty()&&!stack.peek().equals("("))
                            postfix.append(stack.pop());
                        stack.push(ch+"");
                        i++;
                        break;
                    case '×': case '÷':
                        while(!stack.isEmpty()&&(stack.peek().equals("×")||stack.peek().equals("÷")))
                            postfix.append(stack.pop());
                        stack.push(ch+"");
                        i++;
                        break;
                    case '(':
                        stack.push(ch+"");
                        i++;
                        break;
                    case ')':
                        String out=stack.pop();
                        while(out!=null&&!out.equals("(")){
                            postfix.append(out);
                            out=stack.pop();
                        }
                        i++;
                        break;
                    default:
                        while(i<infix.length()&&((ch>='0'&&ch<='9')||ch=='.')){
                            postfix.append(ch);
                            i++;
                            if(i<infix.length())
                                ch=infix.charAt(i);
                        }
                        postfix.append(" ");
                }
            }
            while(!stack.isEmpty())
                postfix.append(stack.pop());
            return  postfix;
        }
        public static float toValue(StringBuffer postfix){
            Stack<Float> stack=new Stack<Float>();
            float value=0;
            int j=0;
            for(int i=0;i<postfix.length();i++){
                char ch=postfix.charAt(i);
                if((ch>='0'&&ch<='9')||ch=='.'){
                    value=0;
                    while(ch!=' '){
                        while(ch!=' '&&ch!='.'){
                            value=value*10+ch-'0';
                            j++;
                            ch=postfix.charAt(++i);
                        }
                        if(ch!=' '&&ch=='.')
                            ch=postfix.charAt(++i);
                        while(ch!=' '&&(i>=j+2)){
                            BigDecimal valueBD=new BigDecimal(Float.toString(value));
                            BigDecimal chBD=new BigDecimal(Float.toString(ch-'0'));
                            BigDecimal nBD=new BigDecimal(Double.toString(Math.pow(10,i-j-1)));
                            float temp=chBD.divide(nBD).floatValue();
                            BigDecimal tempBD=new BigDecimal(Float.toString(temp));
                            value=valueBD.add(tempBD).floatValue();
                            //value=value+(ch-'0')/((float)Math.pow(10,i-j-1));
                            ch=postfix.charAt(++i);
                        }
                        stack.push(value);
                    }
                }
                else
                    if(ch!=' '){
                        float y=stack.pop(),x=stack.pop();
                        switch(ch){
                            case '+':value=x+y; break;
                            case '-':value=x-y; break;
                            case '×':value=x*y; break;
                            case '÷':value=x/y; break;
                        }
                        stack.push(value);
                    }
            }
            return stack.pop();
        }
    }
}
