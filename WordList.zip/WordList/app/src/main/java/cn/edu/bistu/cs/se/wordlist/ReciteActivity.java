package cn.edu.bistu.cs.se.wordlist;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TableLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Map;

public class ReciteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recite);
        //为ListView注册上下文菜单
        ListView list = (ListView) findViewById(R.id.ReciteWordsLists);
        registerForContextMenu(list);
        Intent intent=getIntent();
        ArrayList<Map<String, String>> items=(ArrayList<Map<String, String>>)intent.getSerializableExtra("result");
        setWordsListView(items);
    }

    private void setWordsListView(ArrayList<Map<String, String>> items){
        SimpleAdapter adapter = new SimpleAdapter(this, items, R.layout.reciteitem,new String[]{Words.Word._ID,Words.Word.COLUMN_NAME_WORD, Words.Word.COLUMN_NAME_MEANING, Words.Word.COLUMN_NAME_SAMPLE},new int[]{R.id.textId,R.id.textViewWord, R.id.textViewMeaning, R.id.textViewSample});
        ListView list = (ListView) findViewById(R.id.ReciteWordsLists);
        list.setAdapter(adapter);
    }


    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        getMenuInflater().inflate(R.menu.contextmenu_recitelistview, menu);
    }


    @Override
    public boolean onContextItemSelected(MenuItem item) {
        TextView textId=null;
        TextView textWord=null;
        TextView textMeaning=null;
        TextView textSample=null;
        AdapterView.AdapterContextMenuInfo info=null;
        View itemView=null;
        switch (item.getItemId()){
            case R.id.action_showSample:
                info=(AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
                itemView=info.targetView;
                textSample =(TextView)itemView.findViewById(R.id.textViewSample);
                String strSample=textSample.getText().toString();
                ReciteSampleDialog(strSample);
                break;
            case R.id.action_showMeaning:
                info=(AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
                itemView=info.targetView;
                textMeaning =(TextView)itemView.findViewById(R.id.textViewMeaning);
                String strMeaning=textMeaning.getText().toString();
                ReciteMeaningDialog(strMeaning);
                break;
        }
        return true;
    }


    private void ReciteMeaningDialog(final String strMeaning){
        final TableLayout tableLayout = (TableLayout) getLayoutInflater().inflate(R.layout.recite_meaning, null);
        ((EditText)tableLayout.findViewById(R.id.txtReciteMeaning)).setText(strMeaning);
        new AlertDialog.Builder(this)
                .setTitle("单词翻译")
                .setView(tableLayout)//设置视图
                .setPositiveButton("知道啦", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) { }
        }).create().show();
    }

    private void ReciteSampleDialog(final String strSample){
        final TableLayout tableLayout = (TableLayout) getLayoutInflater().inflate(R.layout.recite_sample, null);
        ((EditText)tableLayout.findViewById(R.id.txtReciteSample)).setText(strSample);
        new AlertDialog.Builder(this)
                .setTitle("单词示例")
                .setView(tableLayout)//设置视图
                .setPositiveButton("知道啦", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) { }
                }).create().show();
    }
}
